#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"lddbus"


#endif
