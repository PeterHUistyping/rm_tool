# Kernel Modules vs Applications

## User space and kernel space

## Concurrency in the kernel

## Interrupt Context and Process Context

# ¶ The end
