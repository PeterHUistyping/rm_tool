# rbtree

rbtree is a fundamental data structure in kernel, It implementes a key-val map
data structure for fast searching, adding and erasing.

---

### ¶ The end
