#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"simple"
#define DEV_NR			2

#endif
