#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"proc_fs_basic"
#define SUB_DIR_NAME		"proc_demo"
#define PROC_FS_NAME		"proc_fs"
#define PROC_FS_NAME_MUL	"proc_fs_mul"

#define PRINT_NR		3

#endif
