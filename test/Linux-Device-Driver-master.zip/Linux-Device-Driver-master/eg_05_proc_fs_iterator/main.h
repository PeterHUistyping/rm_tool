#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"proc_fs_iterator"
#define PROC_FILE_NAME		"proc_fs_iterator"
#define DATA_BLOCK_NUM		7

#endif
