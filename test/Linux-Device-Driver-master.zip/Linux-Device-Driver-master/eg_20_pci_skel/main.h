#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"pci_skel"
#define SHORT_NR_PORTS		1

#endif
