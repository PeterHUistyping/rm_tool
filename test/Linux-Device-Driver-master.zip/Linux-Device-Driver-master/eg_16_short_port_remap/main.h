#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"short_port_remap"
#define SHORT_NR_PORTS		1

#endif
