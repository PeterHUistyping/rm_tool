#ifndef _MAIN_H
#define _MAIN_H

#define MODULE_NAME		"short_mmio"
#define SHORT_NR_PORTS		1

#endif
